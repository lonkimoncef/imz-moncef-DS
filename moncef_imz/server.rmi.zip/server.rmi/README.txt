run it as following:
    
    mvn clean compile exec:java -Dexec.args="0.0.0.0 4321"
    
Ensure java 1.8 is installed and JAVA_HOME environment variable is available.
Also, either provide a full path to mvn.bat file or add bin folder from your maven installation to PATH.